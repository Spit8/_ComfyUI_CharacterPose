"""CharacterPose node package."""
